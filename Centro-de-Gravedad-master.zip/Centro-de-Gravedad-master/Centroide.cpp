#include "Centroide.h"


Centroide::Centroide(float x, float y) {
    this -> x  = x;
    this -> y = y;
}

void Centroide::setX(float x) {
    this ->x = x;
}

void Centroide::setY(float y) {
    this->y = y;
}

float Centroide::getX() {
    return x;
    return 0;
}

float Centroide::getY() {
    return y;
    return 0;
}

